#include <stdio.h>
#include "parseur.tab.h"

extern FILE *yyin;
extern int tableau[256];

int yywrap(void) { return 1; }

int main(int argc, char **argv) {

    if (argc > 1) {
        if (!(yyin = fopen(argv[1], "r"))) {
            perror(argv[1]);
            return 1;
        }
    }

    if (yyparse() == 0) {
        printf("Analyse réussie.\n"); 
        printf("0 ce repete %d\n", tableau[0]);
        printf("1 ce repete %d\n", tableau[1]);
    }
    else { printf("Analyse échouée.\n"); }
    return 0;
}